// ==UserScript==
// @name        【edge】阅读模式
// @namespace   Violentmonkey Scripts
// @match       *://*.*/*
// @grant       none
// @version     1.0
// @author      -
// @description 2023/2/3 18:56:05
// ==/UserScript==


(function() {
    'use strict';
    window.onload = function(){
        //do something
       const _pop_button = document.createElement("button")
       _pop_button.style = `
          position: fixed;
          padding:10px;
          top:50px;
          right:50px;
          background-color:antiquewhite;

       `
       _pop_button.id = "_read"
       _pop_button.innerText = "阅读模式"

       _pop_button.addEventListener("click",e=>{
         const _href = window.location.href
         let domain = "read://" +_href.match(/^(.*\/\/.*\.[a-z]+\/).*$/)[1]+domain.replace("//","_")+"?"+encodeURIComponent(window.location.href)
         console.log(domain)
         window.location.href = domain
       })

       document.body.appendChild(_pop_button)
    }
})();