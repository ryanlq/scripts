// ==UserScript==
// @name        youtube playlist
// @namespace   Violentmonkey Scripts
// @match       *://*.youtube.com/playlist*
// @grant       none
// @version     1.0
// @author      -
// @description 2023/2/3 18:56:05
// ==/UserScript==


(function() {
    'use strict';
    function sleep( seconds ) {
      var start = new Date().getTime();
      while ( (new Date().getTime() - start) < (seconds * 1000) ) {
        // zZz...
      }
    }
    let playlists

    function custom_action(){
      console.log('custom_action')
      function add(index){
          playlists[index].querySelector("button").click()
          sleep(2000)
          let menus = document.querySelectorAll("ytd-menu-service-item-renderer")
          menus[2].click()

          sleep(2000)
          list = document.querySelectorAll("ytd-playlist-add-to-option-renderer")
          list[1].querySelector('tp-yt-paper-checkbox').click()

          sleep(2000)
          document.querySelector("ytd-add-to-playlist-renderer").querySelector("yt-icon[icon=close]").click()

          sleep(2000)
      }
      function delay(i) {
        sleep(2000)
          add(i)
      }

      const start = 0,end = start+60;
      //for(var i = start; i < end; i++) {

      for(var i = 0; i < 60; i++) {
        delay(i)
      }
    }
    window.onload = function(){
        //do something
      playlists = document.querySelectorAll("ytd-playlist-video-renderer")

      let _btnn = document.createElement("button")
      _btnn.style = `
          position:fixed;
          padding:5px;
          background-color:#eee;
          top:30px;
          right:30px;
          z-index:999;
        `
      _btnn.innerText = "添加"
      _btnn.addEventListener("click",()=>custom_action())
      document.body.appendChild(_btnn)
    }
})();